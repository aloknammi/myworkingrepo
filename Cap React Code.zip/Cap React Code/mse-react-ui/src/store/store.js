import create from 'zustand'

const useStore = create((set) => ({
    isLoading: true,
    setIsLoading: (bool) => set(() => ({ isLoading: bool }))
}))

export default useStore
