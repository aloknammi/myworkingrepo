import React, { lazy, Suspense } from 'react'
import { BrowserRouter as Router, Link, Route, Routes } from 'react-router-dom';
import './App.css';
const About = lazy(() => import('./hooks/lazyLoading/About'));
const ContactUs = lazy(() => import('./hooks/lazyLoading/contact'));
const Home = lazy(() => import('./hooks/lazyLoading/home'));

const RouterComponent = () => {
  return (
    <Router>
        {/* <Suspense fallback={<div>Loading...</div>}> */}  { /* for overall suspenses */ }
        <div>
            <ul>
            <li>
                <Link to="/">Home</Link>
            </li>
            <li>
                <Link to="/about">About us</Link>
            </li>
            <li>
                <Link to="/contact">Contact Us</Link>
            </li>
            </ul>
            <hr />
            <Routes>
                <Route exact path="/" element={<Suspense fallback={<div>Loading...</div>}><Home /></Suspense>}/>
                <Route path="/about" element={<Suspense fallback={<div>Loading...</div>}><About /></Suspense>} />
                <Route path="/contact" element={<Suspense fallback={<div>Loading...</div>}><ContactUs /></Suspense>} />
                {/* <Route exact path="/" element={<Home />}/>
                <Route path="/about" element={<About />} />
                <Route path="/contact" element={<ContactUs />} /> */} { /* for overall suspenses */ }
            </Routes>
        </div>
        {/* </Suspense> */}
        </Router>
  );
}

export default RouterComponent;
