import axios from 'axios';

//  once we have all endpoint we need to create .env file and move this code there.
export const BASE_URL =
  'https://ds-aks-pf.walgreens.com/mse/benefit-modeler/api';

const onRequestError = (error) => {
  console.error(`[reqeust error]: [${JSON.stringify(error)}]`);
  return Promise.reject(error);
};

const onRequest = (config) => {
  // once we have token we can get it from cookie and add it here
  config.headers.Authorization = 'token';
  config.headers['Ocp-Apim-Subscription-Key'] =
    '4a109346edf04a06babeba3f9d669227';
  config.headers.env = 'dev';
  config.headers['Content-Type'] = 'application/json';
  config.headers['Access-Control-Allow-Origin'] = '*';
  return config;
};

const getAxiosInstance = () => {
  const instance = axios.create();
  instance.defaults.baseURL = BASE_URL;
  instance.interceptors.request.use(onRequest, onRequestError);
  return instance;
};

const makeGet = () => {
  return (url, option) => {
    const instance = getAxiosInstance(option);
    return instance({
      url,
      method: 'GET',
      withCredentials: false,
      ...option
    });
  };
};

const makePost = () => {
  return (url, option) => {
    const instance = getAxiosInstance(option);
    return instance({
      url,
      method: 'POST',
      withCredentials: false,
      ...option
    });
  };
};

export const axiosInstance = {
  get: makeGet(),
  post: makePost()
};
