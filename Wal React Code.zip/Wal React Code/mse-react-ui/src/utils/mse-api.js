import { axiosInstance } from './axiosConfig';

export const getAllStores = async (payload) => {
  try {
    const response = await axiosInstance.post('/storeList', { data: payload });
    return response.data;
  } catch (error) {
    return error;
  }
};

export const getChartsData = async (payload) => {
  try {
    const response = await axiosInstance.post('/benefitCurve', { data: payload });
    return response.data;
  } catch (error) {
    return error;
  }
};

export const getDepartmentList = async (storeNbr) => {
  try {
    const body = {
      benefitModelID: 1,
      storeNbr: +storeNbr
    };
    const response = await axiosInstance.post('/deptList', { data: body });
    return response.data;
  } catch (error) {
    return error;
  }
};

export const getModeledBenefitData = async (payload) => {
  try {
    const body = {
      benefitModelID: 1,
      storeNbr: payload.selectedStoreId,
      departmentListAndSizes: payload.departmentListAndSizes,
      useHalo: payload.useHalo
    };
    const response = await axiosInstance.post('/modeledBenefits', { data: body });
    return response.data;
  } catch (error) {
    return error;
  }
};
