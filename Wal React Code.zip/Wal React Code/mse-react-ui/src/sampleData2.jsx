{
    "storeNbr": 3571,
    "departmentListAndSizes": [ 
        {
            "departmentID": 3328,
            "benefitsForSizes": [
                {
                    "footage": 10.0,
                    "units": 28.367375906647244,
                    "sales": 28.367375906647244,
                    "grossMargin": 28.367375906647244,
                    "comprehensiveProfit": 28.367375906647244
                },
                {
                    "footage": 15.0,
                    "units": 28.395556020376368,
                    "sales": 28.395556020376368,
                    "grossMargin": 28.395556020376368,
                    "comprehensiveProfit": 28.395556020376368
                },
                {
                    "footage": 25.0,
                    "units": 28.396205747265345,
                    "sales": 28.396205747265345,
                    "grossMargin": 28.396205747265345,
                    "comprehensiveProfit": 28.396205747265345
                }
            ]
        }
    ]
}