import React from 'react';
import PropTypes from 'prop-types';
import { Alert } from 'react-bootstrap';

const AlertBox = ({ variant, children }) => {
  return (
    <Alert key={variant} variant={variant}>
      {children}
    </Alert>
  );
};

AlertBox.propTypes = {
  variant: PropTypes.string,
  children: PropTypes.node
};

export default AlertBox;
