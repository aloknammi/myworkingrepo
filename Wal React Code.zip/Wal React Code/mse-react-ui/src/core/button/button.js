import React from 'react';
import PropTypes from 'prop-types';
import RBButton from 'react-bootstrap/Button';
import './button.scss';

const Button = (props) => {
  const { children, ...rest } = props;
  return <RBButton {...rest}>{children}</RBButton>;
};

Button.propTypes = {
  children: PropTypes.node.isRequired
};

export default Button;
