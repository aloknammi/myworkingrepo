import { useCallback, useState } from "react";

const useToggle = () => {
    const [toggleState, setToggleState] = useState(false);
    const toggle = useCallback(() => setToggleState(!toggleState), [])
    return [toggleState, toggle]
}

export default useToggle

// A simple hook to switch states in toggles. Default is false
// sample use with a button to control Light and Dark mode
// const [lightsMode, setLightsMode] = useToggle()
// <button onClick={setLightsMode}> {lightMode ? 'Light Mode' : 'Dark Mode' } </button>
