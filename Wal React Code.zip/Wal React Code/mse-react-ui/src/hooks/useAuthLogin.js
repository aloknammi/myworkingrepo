import React from "react";
import OAuth2Login from "react-simple-oauth2-login";
import PropTypes from "prop-types";

const useAuthLogin = (props) => {
  const {
    responseType,
    clientId,
    authorizeUri,
    scope,
    onSuccess,
    onFailure,
    redirectUri,
    buttonText,
    className
  } = props;

  return (
    <OAuth2Login
      responseType={responseType}
      clientId={clientId}
      authorizationUrl={authorizeUri}
      redirectUri={redirectUri}
      onSuccess={/*  istanbul ignore next */ (res) => onSuccess?.(res)}
      onFailure={/*  istanbul ignore next */ (err) => onFailure?.(err)}
      scope={scope}
      className={className}
      buttonText={buttonText}
    />
  );
};

// type checking for props
useAuthLogin.propTypes = {
  responseType: PropTypes.string.isRequired,
  clientId: PropTypes.string.isRequired,
  authorizeUri: PropTypes.string.isRequired,
  redirectUri: PropTypes.string,
  className: PropTypes.string,
  scope: PropTypes.string,
  onSuccess: PropTypes.func,
  onFailure: PropTypes.func
};

// default props
useAuthLogin.defaultProps = {
  scope: "email",
  buttonText: "Login",
  onSuccess: () => {},
  onFailure: () => {},
  className: ""
};

export default useAuthLogin;
