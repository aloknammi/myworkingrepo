import React, { Fragment } from "react";

const ContactUs = () => {
return (
    <Fragment>
        <h1>Contact Details</h1>
    </Fragment>
)
}

export default ContactUs
