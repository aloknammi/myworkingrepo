import create from 'zustand';
import { devtools } from 'zustand/middleware';
import {
  getAllStores,
  getDepartmentList,
  getModeledBenefitData,
  getChartsData
} from '../utils/mse-api';

let store = (set) => ({
  storeData: [],
  chartData: [],
  departmentList: null,
  modeledBenefitData: null,
  selectedStoreId: '',
  selectedDepartmentId: '',
  selectedDescDepartmentId: '',
  metricValues: { units: '', sales: '', margin: '', profit: '' },

  setSelectedStoreId: (storeId) => {
    set((state) => ({
      ...state,
      selectedDepartmentId: '',
      selectedStoreId: storeId
    }));
  },
  setDescDepartmentId: (deptId) => {
    set((state) => ({
      ...state,
      selectedDescDepartmentId: deptId
    }));
  },
  setSelectedDepartmentId: (deptId) => {
    const [parsedDeptId] = deptId.split('-');
    set((state) => ({
      ...state,
      selectedDepartmentId: parseInt(parsedDeptId.trim(), 10)
    }));
  },
  setMetricValues: (metricValues) => {
    set((state) => ({ ...state, metricValues }));
  },
  setStoreData: async (input) => {
    const response = await getAllStores(input);
    set((state) => ({ ...state, storeData: response?.Stores || [] }));
  },
  setChartData: async (input) => {
    const response = await getChartsData(input);
    set((state) => ({ ...state, chartData: response }));
  },
  setDepartmentList: async (input) => {
    const response = await getDepartmentList(input);
    set((state) => ({
      ...state,
      selectedDepartmentId: '',
      departmentList: response
    }));
  },
  setModeledBenefitData: async (input) => {
    const response = await getModeledBenefitData(input);
    set((state) => ({ ...state, modeledBenefitData: response }));
  }
});

store = devtools(store);
// create the store
const useAppStore = create(store);
export default useAppStore;
