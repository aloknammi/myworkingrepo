import React from 'react';
import ReactApexChart from 'react-apexcharts';
import PropTypes from 'prop-types';
import useAppStore from '../../store/store';
import { Box } from '@mui/system';

export const Chartss = () => {
  const { selectedDepartmentId, chartData } = useAppStore((state) => state);

  const chartOrderArray = [
    'CHAIN',
    'CLUSTER',
    'STORE',
    'CLUSTER_TREND',
    'STORE_TREND'
  ];

  const states = {
    series: [],
    options: {
      chart: {
        height: 550,
        type: 'scatter',
        zoom: {
          enabled: false,
          type: 'xy'
        }
      },
      markers: { size: [] },
      xaxis: {
        tickAmount: 10,
        labels: {
          formatter: function (val) {
            return parseFloat(val).toFixed(0);
          }
        },
        title: {
          text: 'FEET',
          rotate: -90,
          offsetX: -10,
          offsetY: 0,
          style: {
            color: 'black',
            fontSize: '20px',
            fontFamily: 'Helvetica, Arial, sans-serif',
            fontWeight: 500
          }
        }
      },
      yaxis: {
        tickAmount: 7,
        labels: {
          formatter: function (val) {
            return parseFloat(val).toFixed(0);
          }
        },
        title: {
          text: 'KPI',
          rotate: -90,
          offsetX: -10,
          offsetY: 0,
          style: {
            color: 'black',
            fontSize: '20px',
            fontFamily: 'Helvetica, Arial, sans-serif',
            fontWeight: 500
          }
        },
        decimalsInFloat: 0
      }
    }
  };

  const seriesData = [];

  let item = [];
  if (selectedDepartmentId && chartData?.length) {
    item = chartData.find((i) => {
      return `${i.departmentID}` === `${selectedDepartmentId}`;
    });
    if (item) {
      seriesData.push(item);
    }
  }

  if (seriesData && seriesData?.length > 0) {
    chartOrderArray.map((orderItemStr) => {
      if (seriesData[0][orderItemStr]) {
        states.series.push({
          name: orderItemStr,
          data: seriesData[0][orderItemStr],
          type:
            orderItemStr === 'CLUSTER_TREND' || orderItemStr === 'STORE_TREND'
              ? 'line'
              : 'scatter'
        });
        if (
          orderItemStr === 'CLUSTER_TREND' ||
          orderItemStr === 'STORE_TREND'
        ) {
          states.options.markers.size.push(0);
        } else {
          states.options.markers.size.push(6);
        }
      }
      return orderItemStr;
    });
  }
  if (selectedDepartmentId) {
    return (
      <Box sx={{ width: '100%' }}>
        <ReactApexChart
          style={{ width: '100%' }}
          options={states.options}
          series={states.series}
          type="line"
          height={400}
        />
      </Box>
    );
  } else {
    return (
      <div className="mixed-chart">
        <h2>Please select department</h2>
      </div>
    );
  }
};

Chartss.propTypes = {
  storeInfo: PropTypes.any
};
