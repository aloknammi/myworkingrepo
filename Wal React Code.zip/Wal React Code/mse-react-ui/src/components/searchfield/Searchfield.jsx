import React, { useRef, useMemo, useState, useEffect } from 'react';
import Box from '@mui/material/Box';
import PropTypes from 'prop-types';
import Autocomplete from '@mui/material/Autocomplete';
import TextField from '@mui/material/TextField';
import { Button } from '@mui/material';
import useAppStore from '../../store/store';
import './searchfield.scss';

export const Searchfield = ({ handleSearch }) => {
  const [listOfDeptIds, setListOfDeptIds] = useState([]);
  const isStoreFetched = useRef();
  const storeState = useAppStore((state) => state);

  const { selectedStoreId, selectedDescDepartmentId, metricValues } = storeState;

  const listOfStoreIds = useMemo(
    () =>
      storeState?.storeData?.map((item) => `${item}`)?.sort((a, b) => a - b),
    [storeState?.storeData]
  );

  useEffect(() => {
    // call only once
    if (isStoreFetched.current) return true;
    isStoreFetched.current = true;

    storeState?.setStoreData({ benefitModelID: 1 });

    return () => {
      isStoreFetched.current = false;
    };
  }, []);

  useEffect(() => {
    const { departmentList } = storeState;
    if (departmentList?.deptList && departmentList?.deptDesc) {
      const { deptList, deptDesc } = departmentList;
      let list = [];
      list = deptList.map((el, index) => {
        return `${el} - ${deptDesc[index] || 'NONE'}`;
      });
      setListOfDeptIds(list);
    }
  }, [storeState?.departmentList]);

  useEffect(() => {
    if (selectedStoreId) {
      storeState?.setDepartmentList(selectedStoreId);
    }
  }, [selectedStoreId]);

  const handleInput = function (e) {
    storeState.setMetricValues({
      ...storeState.metricValues,
      [e.target.name]: e.target.value
    });
  };

  const handleSubmit = (e) => {
    e.preventDefault();
  };

  const isGoEnabled = () => {
    return (
      selectedStoreId &&
      selectedDescDepartmentId &&
      metricValues.margin !== '' &&
      metricValues.profit !== '' &&
      metricValues.sales !== '' &&
      metricValues.units
    );
  };

  return (
    <div className="searchfield">
      <form
        id="registrationForm1"
        action="/"
        method="POST"
        onSubmit={handleSubmit}
      >
        <div className="wrapper">
          <Autocomplete
            disablePortal
            className=""
            id="combo-box-demo"
            options={listOfStoreIds}
            value={selectedStoreId}
            onChange={(_event, newTeam) => {
              setListOfDeptIds([]);
              storeState.setSelectedStoreId(newTeam);
            }}
            sx={{
              width: {
                xs: '100%',
                md: '20ch'
              }
            }}
            renderInput={(params) => <TextField {...params} label="Store" />}
          />

          <Autocomplete
            disablePortal
            className=""
            id="combo-box-demo"
            options={Array.from(listOfDeptIds, (x) => `${x}`) || []}
            value={selectedDescDepartmentId}
            onChange={(_event, newTeam) => {
              storeState.setDescDepartmentId(newTeam);
              storeState.setSelectedDepartmentId(newTeam);
            }}
            sx={{
              width: {
                xs: '100%',
                md: '28ch'
              }
            }}
            renderInput={(params) => (
              <TextField {...params} label="Department" />
            )}
          />

          <Box
            sx={{
              '& > :not(style)': {
                m: 1,
                width: {
                  xs: '100%',
                  sm: '13ch',
                  md: '15ch'
                }
              }
            }}
            noValidate
            autoComplete="off"
          >
            <TextField
              onKeyPress={(event) => {
                if (!/[0-9]/.test(event.key)) {
                  event.preventDefault();
                }
              }}
              onChange={handleInput}
              name="units"
              value={metricValues.units}
              id="outlined-basic"
              label="Units"
              variant="outlined"
            />
          </Box>

          <Box
            sx={{
              '& > :not(style)': {
                m: 1,
                width: {
                  xs: '100%',
                  sm: '13ch',
                  md: '15ch'
                }
              }
            }}
            noValidate
            autoComplete="off"
          >
            <TextField
              onKeyPress={(event) => {
                if (!/[0-9]/.test(event.key)) {
                  event.preventDefault();
                }
              }}
              onChange={handleInput}
              name="sales"
              value={metricValues.sales}
              id="outlined-basic"
              label="Sales"
              variant="outlined"
            />
          </Box>

          <Box
            sx={{
              '& > :not(style)': {
                m: 1,
                width: {
                  xs: '100%',
                  sm: '13ch',
                  md: '15ch'
                }
              }
            }}
            noValidate
            autoComplete="off"
          >
            <TextField
              onKeyPress={(event) => {
                if (!/[0-9]/.test(event.key)) {
                  event.preventDefault();
                }
              }}
              onChange={handleInput}
              name="margin"
              value={metricValues.margin}
              id="outlined-basic"
              label="Comprehensive Profit"
              variant="outlined"
            />
          </Box>

          <Box
            sx={{
              '& > :not(style)': {
                m: 1,
                width: {
                  xs: '100%',
                  sm: '13ch',
                  md: '15ch'
                }
              }
            }}
            noValidate
            autoComplete="off"
          >
            <TextField
              onKeyPress={(event) => {
                if (!/[0-9]/.test(event.key)) {
                  event.preventDefault();
                }
              }}
              onChange={handleInput}
              name="profit"
              value={metricValues.profit}
              id="outlined-basic"
              label="Gross Profit"
              variant="outlined"
            />
          </Box>

          <Button
            variant="contained"
            className="button"
            disabled={!isGoEnabled()}
            onClick={handleSearch}
          >
            Go
          </Button>
        </div>
      </form>
    </div>
  );
};

Searchfield.propTypes = {
  handleSearch: PropTypes.any
};
