import Box from '@mui/material/Box';
import Autocomplete from '@mui/material/Autocomplete';
import InputLabel from '@mui/material/InputLabel';
import MenuItem from '@mui/material/MenuItem';
import FormControl from '@mui/material/FormControl';
import Select from '@mui/material/Select';
import React, { useState, useEffect } from 'react';
import './kpi.scss';
import Chart from 'react-apexcharts';
import PropTypes from 'prop-types';
import TextField from '@mui/material/TextField';
import { bdata } from './bdata';
import useAppStore from '../../store/store';

export const Kpi = () => {
  const { selectedStoreId, selectedDepartmentId } = useAppStore((state) => state);

  const [department1, setDepartment1] = useState();
  const [department2, setDepartment2] = useState();
  const [department3, setDepartment3] = useState();
  const [department4, setDepartment4] = useState();
  const [footage, setFootage] = useState(0);
  const [finalPlotData1, setFinalPlotData1] = useState();
  const [finalPlotData2, setFinalPlotData2] = useState();
  const [finalPlotData3, setFinalPlotData3] = useState();
  const [finalPlotData4, setFinalPlotData4] = useState();
  const [max, setMax] = useState();
  const [input, setInput] = useState({
    units: '',
    sales: '',
    margin: '',
    profit: ''
  });

  const setModeledBenefitData = useAppStore(
    (state) => state.setModeledBenefitData
  );
  const departmentList = useAppStore((state) => state.departmentList);
  const modeledBenefitData = useAppStore((state) => state.modeledBenefitData);

  useEffect(() => {
    if (departmentList && selectedStoreId) {
      const footageList = [10, 15, 25];
      const useHalo = false;
      const departmentListAndSizes = departmentList?.deptList.map((dept) => {
        return {
          departmentID: +dept,
          footage: footageList
        };
      });
      setModeledBenefitData({ selectedStoreId, departmentListAndSizes, useHalo });
    }
  }, [departmentList, selectedStoreId]);

  const handleInput = function (e) {
    setInput({
      ...input,
      [e.target.name]: e.target.value
    });
  };

  const footageChange = (event) => {
    setFootage(event.target.value);
  };

  const getConsolidatedData = (departmentId) => {
    const consolidatedData = [];
    if (departmentId && modeledBenefitData) {
      const department = modeledBenefitData?.departmentListAndSizes.find(
        (item) => item.departmentID === +departmentId
      );

      const reducedData = department?.benefitsForSizes.reduce((prev, cur) => {
        Object.entries(cur).forEach(([key, value]) => {
          prev[key] = prev[key] || [];
          if (!prev[key].includes(value)) prev[key].push(value);
        });
        return prev;
      }, Object.create(null));

      if (reducedData) {
        for (const [key, value] of Object.entries(reducedData)) {
          consolidatedData.push({
            name: key.charAt(0).toUpperCase() + key.slice(1),
            data: value
          });
        }
      }
      return consolidatedData;
    }
  };

  useEffect(() => {
    setFinalPlotData1(getConsolidatedData(department1));
    setFinalPlotData2(getConsolidatedData(department2));
    setFinalPlotData3(getConsolidatedData(department3));
    setFinalPlotData4(getConsolidatedData(department4));
  }, [department1, department2, department3, department4]);

  const getStateData = (finalPlotData, departmentId) => {
    return {
      series: finalPlotData,
      options: {
        chart: { height: 350, type: 'line', zoom: { enabled: false } },
        dataLabels: { enabled: false },
        stroke: {
          width: [5, 5, 5, 5, 5],
          curve: 'straight',
          dashArray: [0, 0, 0, 0, 0]
        },
        title: { text: `Department - ${departmentId}`, align: 'left' },
        legend: {
          tooltipHoverFormatter: function (val, opts) {
            return `${val} - ${
              opts.w.globals.series[opts.seriesIndex][opts.dataPointIndex]
            }`;
          }
        },
        markers: { size: 0, hover: { sizeOffset: 6 } },
        xaxis: { categories: ['1', '2', '3'] },
        yaxis: { decimalsInFloat: 0 },
        grid: { borderColor: '#f1f1f1' }
      }
    };
  };

  useEffect(() => {
    const selectedDept = bdata.find(
      (item) => item.departmentID === +selectedDepartmentId
    );
    if (selectedDept) {
      setMax(getMax(selectedDept.STORE_TREND));
    }
  }, [selectedDepartmentId]);

  function getMax (a) {
    return Math.max(...a.map((e) => (Array.isArray(e) ? getMax(e) : e)));
  }

  const buildOptions = () => {
    if (max) {
      const options = [];
      for (let i = 1; i <= parseInt(max); i++) {
        options.push(
          <MenuItem key={i + 1} value={i + 1}>
            {i + 1}
          </MenuItem>
        );
      }
      return options;
    }
  };

  // eslint-disable-next-line no-shadow
  const renderChart = (finalPlotData, department) => {
    if (finalPlotData?.length > 0) {
      return (
        <div>
          {department && (
            <div id="chart">
              <Chart
                options={getStateData(finalPlotData, department)?.options}
                series={getStateData(finalPlotData, department)?.series}
                type="line"
                width="450"
              />
            </div>
          )}
        </div>
      );
    } else {
      return (
        <div>
          <p className="nodata" />
        </div>
      );
    }
  };

  return (
    <div className="container">
      <div className="wrapper">
        <Box sx={{ minWidth: 120 }} className="fg">
          <FormControl fullWidth>
            <InputLabel id="demo-simple-select-label">Footage</InputLabel>
            <Select
              labelId="demo-simple-select-label"
              id="demo-simple-select"
              value={footage}
              label="Footage"
              onChange={footageChange}
            >
              <MenuItem value="0">Select</MenuItem>
              {buildOptions()}
            </Select>
          </FormControl>
        </Box>

        <Box
          className="fg"
          component="form"
          sx={{ minWidth: 120 }}
          noValidate
          autoComplete="off"
        >
          <TextField
            onKeyPress={(event) => {
              if (!/[0-9]/.test(event.key)) {
                event.preventDefault();
              }
            }}
            onChange={handleInput}
            name="footage1"
            value={input.margin}
            id="outlined-basic"
            label="Footage 1"
            variant="outlined"
          />
        </Box>

        <Box
          className="fg"
          component="form"
          sx={{ minWidth: 120 }}
          noValidate
          autoComplete="off"
        >
          <TextField
            onKeyPress={(event) => {
              if (!/[0-9]/.test(event.key)) {
                event.preventDefault();
              }
            }}
            onChange={handleInput}
            name="footage2"
            value={input.margin}
            id="outlined-basic"
            label="Footage 2"
            variant="outlined"
          />
        </Box>

        <Box
          className="fg"
          component="form"
          sx={{ minWidth: 120 }}
          noValidate
          autoComplete="off"
        >
          <TextField
            onKeyPress={(event) => {
              if (!/[0-9]/.test(event.key)) {
                event.preventDefault();
              }
            }}
            onChange={handleInput}
            name="footage3"
            value={input.margin}
            id="outlined-basic"
            label="Footage 3"
            variant="outlined"
          />
        </Box>
      </div>
      <div className="halo">
        <div className="dropdown">
          <Autocomplete
            disablePortal
            className="dd"
            id="combo-box-demo"
            options={departmentList?.deptList}
            onChange={(_event, newTeam) => {
              if (newTeam !== '0') setDepartment1(newTeam);
            }}
            sx={{ width: 300 }}
            renderInput={(params) => (
              <TextField {...params} label="Department" />
            )}
          />

          <Autocomplete
            disablePortal
            className="dd"
            id="combo-box-demo"
            options={departmentList?.deptList}
            onChange={(_event, newTeam) => {
              if (newTeam !== '0') setDepartment2(newTeam);
            }}
            sx={{ width: 300 }}
            renderInput={(params) => (
              <TextField {...params} label="Department" />
            )}
          />

          <Autocomplete
            disablePortal
            className="dd"
            id="combo-box-demo"
            options={departmentList?.deptList}
            value={department3}
            onChange={(_event, newTeam) => {
              if (newTeam !== '0') setDepartment3(newTeam);
            }}
            sx={{ width: 300 }}
            renderInput={(params) => (
              <TextField {...params} label="Department" />
            )}
          />

          <Autocomplete
            disablePortal
            className="dd"
            id="combo-box-demo"
            options={departmentList?.deptList}
            value={department4}
            onChange={(_event, newTeam) => {
              if (newTeam !== '0') setDepartment4(newTeam);
            }}
            sx={{ width: 300 }}
            renderInput={(params) => (
              <TextField {...params} label="Department" />
            )}
          />
        </div>
      </div>
      <div className="containers">
        {renderChart(finalPlotData1, department1)}
        {renderChart(finalPlotData2, department2)}
        {renderChart(finalPlotData3, department3)}
        {renderChart(finalPlotData4, department4)}
      </div>
    </div>
  );
};

Kpi.propTypes = {
  selectedDepartmentId: PropTypes.any,
  selectedStoreId: PropTypes.any
};
