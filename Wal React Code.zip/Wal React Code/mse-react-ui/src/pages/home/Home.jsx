import React from 'react';
// import { Sidebar } from "../../components/sidebar/Sidebar"
import { Navbar } from '../../components/navbar/Navbar';
import { Searchfield } from '../../components/searchfield/Searchfield';
import { Kpi } from '../../components/kpi/Kpi';
import { Chartss } from '../../components/chart/Chartss';
import { Halo } from '../../components/halo/Halo';
import './home.scss';
import useAppStore from '../../store/store';

const Home = () => {
  const {
    setChartData,
    selectedStoreId,
    selectedDepartmentId,
    metricValues: mv
  } = useAppStore((state) => state);

  const handleSearch = () => {
    setChartData({
      benefitModelID: 1,
      storeNbr: +selectedStoreId,
      departmentList: [selectedDepartmentId],
      benefitBlend: [
        parseFloat(mv.units),
        parseFloat(mv.sales),
        parseFloat(mv.margin),
        parseFloat(mv.profit)
      ],
      useHalo: false
    });
  };

  return (
    <div className="home">
      <div className="homeContainer">
        <Navbar />

        <div className="widgetsfield">
          <Searchfield handleSearch={handleSearch} />
        </div>

        <div className="charts">
          <Chartss />
        </div>

        <div className="widgetsfield">
          <Kpi />
        </div>

        <div className="widgetsfield">
          <Halo />
        </div>
      </div>
    </div>
  );
};

export default Home;
