Internal working branch to serve as parallel master. 


## REACT UI – SPACE BENEFIT CURVE VISUALIZATION

#### Contents
1.	OVERVIEW OF THE APPLICATION<br />
2.	SPACE BENEFIT CURVE - REACT USER INTERFACE<br />
-Steps to Display Benefit curve Visual plot	<br />
-Sample Visualization of Benefit Curve	<br />
3.	COMPARISON  VISUALIZATION FOR CURRENT BENEFITS	
-Steps to Display Current Benefits Comparison plots	<br />
-Sample Visualization of Current Benefits Curve	<br />
4.	COMPARISON VISUALIZATION FOR MODELLED BENEFITS - HALO EFFECT	
-Steps to Display Modeled Benefits Comparison plots	<br />
-Sample Visualization of Current Benefits Curve<br />


## 1.	Overview of the Application

Application Name 	: React UI for Space Benefit Curve Visualization<br />
End Users	Data Science Team<br />

#### Brief Description:
Data Science stakeholders will view space benefit curve, the REACT UI will need to utilize the API currently being developed for the MSO application. React space-benefit curve visualization will produce a visualization for a single store/department type; does not include any additional visualizations, e.g., reporting dashboard to formally track success criteria, such as Net Sales, listed on the previous slide over time

#### High-Level Wireframe Design
<div align="center">
    <img src="/Screenshots/Picture1.jpg" width="400px"</img> 
</div>

#### Example:   

<div align="center">
    <img src="/Screenshots/Picture2.jpg" width="500px"</img> 
</div>

## Space Benefit Curve - React User Interface

#### Steps to Display Visual Plot of Benefit Curve for a Specific Department of a Specific Store<br />

•	User will select main store<br />
•	User will select department<br />
•	User will provide the Units, Sales, Margin, Profit values with a combined total of not more than 100 and Click on Go. <br />

#### Example:  
<div align="center">
    <img src="/Screenshots/Picture3.jpg" width="500px"</img> 
</div>

<div align="center">
    <img src="/Screenshots/Picture4.jpg" width="500px"</img> 
</div>

<div align="center">
    <img src="/Screenshots/Picture5.jpg" width="500px"</img> 
</div>

## Comparison Plots Visualization for Current Benefits

#### Steps to Display Four Comparison Plots of Current Benefits Model with a list of departments for a Specific Store.<br />

•	User will select footage value for X axis (Note: Maximum Footage Value is pulled from Benefit Curve Plot)<br />
•	User will enter footage values of Current Benefits for Y Axis.<br />
•	User will select department from drop down<br />

#### Example:  
<div align="center">
    <img src="/Screenshots/Picture7.jpg" width="500px"</img> 
</div>

<div align="center">
    <img src="/Screenshots/Picture6.jpg" width="500px"</img> 
</div>

## Comparison Plots Visualization for Modelled Benefits with HALO Effect
 
#### Steps to Display Four Comparison Plots of Modeled Benefits with a list of departments for a Specific Store.<br />

•	Halo Effect is selected, UI will request values Store ID and Department ID from the drop down.<br />
•	User will select Store ID.<br />
•	User will select a department from the drop-down.<br />

#### Example:  

<div align="center">
    <img src="/Screenshots/Picture9.jpg" width="500px"</img> 
</div>

<div align="center">
    <img src="/Screenshots/Picture10.jpg" width="500px"</img> 
</div>

<div align="center">
    <img src="/Screenshots/Picture8.jpg" width="500px"</img> 
</div>

#### VERSION 1.0
Prepared By	Nammi, Alok & Chakraborty, Saheb	10/03/2022